﻿using System;
using CalculatorService;

namespace ConsoleDemoSOAP
{
    class Program
    {
        static void Main(string[] args)
        {
            CalculatorSoapClient calculator = new CalculatorSoapClient(CalculatorSoapClient.EndpointConfiguration.CalculatorSoap);
            int vysledek = calculator.Add(10, 2);

            Console.WriteLine("Výsledek je "+vysledek);
        }
    }
}
